* The .ipynb file stores the code.

* The images attached are the document frequencies of the respective queries passed.